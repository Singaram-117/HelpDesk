from django.shortcuts import render
from django.http import HttpResponse
from helpdesk.modules.Functionalities import *
from helpdesk.modules.ADTS import LinkedList

# Create your views here.

# data stored here
USER_OBJECTS_LST = []
TICKET_OBJECTS_LST = []
# Global variabals to maintain states
USER = None
LOGGED_IN = False
current_heap = None
Elec_agent = hashTable(10)
Furn_agent = hashTable(10)
Plumb_agent = hashTable(10)
heap = hashTable(10)
# loading the data from csv files
USER_OBJECTS_LST    = objs_lst_reader(".\\helpdesk\\CSV_Files\\user_objs.csv",
                            User, ".\\helpdesk\\CSV_Files\\user_tnl.csv")
TICKET_OBJECTS_LST  = objs_lst_reader(".\\helpdesk\\CSV_Files\\ticket_objs.csv",
                            Ticket)
# creating hash tables to store agent details
# electrical category
heap_tuple = heap_reader(".\\helpdesk\\CSV_Files\\agent_tnl.csv", TICKET_OBJECTS_LST)
Elec_agent['agent_name']  = 'elec#agent'
Elec_agent['mail']        = 'elecagent@gmail.com'
Elec_agent['password']    = 'elec#agent'
heap['Electrical']        = heap_tuple[0]
# furniture category
Furn_agent['agent_name']  = 'furn#agent'
Furn_agent['mail']        = 'furnagent@gmail.com'
Furn_agent['password']    = 'furn#agent'
heap['Furniture']         = heap_tuple[1]
# plumbing category
Plumb_agent['agent_name']  = 'plumb#agent'
Plumb_agent['mail']        = 'plumbagent@gmail.com'
Plumb_agent['password']    = 'plumb#agent'
heap['Plumbing']           = heap_tuple[2]


def home(request):
    LOGGED_IN = False
    print(Elec_agent, Furn_agent, Plumb_agent)
    return render(request, 'home.html')


def log_in(request):
    global USER, LOGGED_IN
    # if request came from login page page
    if request.method == 'POST':
        email_user  = request.POST['email_user']
        password    = request.POST['password']
        validated, USER = validate_credentials(email_user, password, USER_OBJECTS_LST)
        print(f"email \t: {email_user}\npassword \t: {password}\nvalidated \t: {validated}")
        if not validated:
            return render(request, 'log-in.html', {'error': True})
        LOGGED_IN = True
        return user_tickets(request)
    # if request came from home page page
    LOGGED_IN = False
    return render(request, 'log-in.html')


def create_ticket(request):
    global TICKET_OBJECTS_LST, USER
    if request.method == 'POST':
        issue    = request.POST['description']
        category = request.POST['issue-category']
        room_no  = request.POST['room-no']
        ticket = Ticket(category, issue, room_no)
        TICKET_OBJECTS_LST.append(ticket)
        print("details\n")
        ticket_no = ticket.get_ticket_no()
        USER.add_ticket_no(ticket_no)
        heap[category].add(ticket, ticket.get_raised(),
                            ticket.get_priority())
        writer()    # to write the created data
        return user_tickets(request) 
    print("in")
    return render(request,'create-ticket.html', 
        {'user_name':USER.get_username(), 'mail':USER.get_email()})


def agent_log_in(request):
    global LOGGED_IN, current_heap
    LOGGED_IN = False
    if request.method == 'POST':
        email_name = request.POST['email-name']
        password   = request.POST['password']
        if ((Elec_agent['agent_name'] == email_name or
            Elec_agent['mail'] == email_name ) 
            and Elec_agent['password'] == password):
            current_heap = heap['Electrical']
            LOGGED_IN = True
        elif ((Furn_agent['agent_name'] == email_name or
            Furn_agent['mail'] == email_name ) 
            and Furn_agent['password'] == password):
            current_heap = heap['Furniture']
            LOGGED_IN = True
        elif ((Plumb_agent['agent_name'] == email_name or
            Plumb_agent['mail'] == email_name ) 
            and Plumb_agent['password'] == password):
            current_heap = heap['Plumbing']
            LOGGED_IN = True
        if LOGGED_IN:
            request.method = 'GET'
            return agent_tickets(request)
        # if invalid credentials
        return render(request, 'agent-log-in.html', {'error':True})
    
    return render(request, 'agent-log-in.html')


def sign_up(request):
    if request.method == 'POST':
        pass
    return render(request, 'sign-up.html')


def ticket_status(request):
    return render(request, 'check-ticket-status.html')


def user_tickets(request):
    print(LOGGED_IN)
    if LOGGED_IN:
        tnl = USER.get_tnl()
        print(tnl)
        ticket_obj_attr_lst = LinkedList()
        for ticket_no in tnl:
            for obj in TICKET_OBJECTS_LST:
                if ticket_no == obj.get_ticket_no():
                    ticket_obj_attr_lst.append(obj.get_attributes())
        print("inside")
        return render(request, 'user-tickets.html',
                       {'obj_lst':ticket_obj_attr_lst})


def agent_tickets(request):
    if request.method == "POST":
        status = request.POST['status']
        print(status)
        max_tup = current_heap.max()
        max_tup[0].update_status(status)
        if status == 'Closed':
            current_heap.pop()
        writer() # to save the changes
        request.method = 'GET'
        return agent_tickets(request)

    if LOGGED_IN:
        ticket_tup_lst = []
        for tup in current_heap:
            attr_tup = tup[0].get_attributes()
            for user in USER_OBJECTS_LST:
                # checking if ticket no is in the user tnl list
                if attr_tup[0] in user.get_tnl():   
                    attr_tup += (user.get_username(),
                                  user.get_mobile_no())
            ticket_tup_lst.append(attr_tup)
        return render(request, 'agent-ticket-details.html',
                     {'max':ticket_tup_lst[0],'ticlst':ticket_tup_lst[1:]})
    

# writer to write the objects back as soon as created
def writer():
    global USER_OBJECTS_LST, TICKET_OBJECTS_LST
    global heap
    objs_lst_writer(".\\helpdesk\\CSV_Files\\user_objs.csv",
     USER_OBJECTS_LST, ".\\helpdesk\\CSV_Files\\user_tnl.csv")
    objs_lst_writer(".\\helpdesk\\CSV_Files\\ticket_objs.csv",
     TICKET_OBJECTS_LST )
    heap_writer(".\\helpdesk\\CSV_Files\\agent_tnl.csv", 
                (heap['Electrical'], heap['Furniture'], heap['Plumbing']))
    